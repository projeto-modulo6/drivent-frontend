export default function Hotel() {
  return 'Hotel: Em breve!';
}
