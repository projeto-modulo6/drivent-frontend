export default function Certificate() {
  return 'Certificado: Em breve!';
}
