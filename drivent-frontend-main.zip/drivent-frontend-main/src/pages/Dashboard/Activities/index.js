export default function Activities() {
  return 'Atividades: Em breve!';
}
