import PersonalInformationForm from '../../../components/PersonalInformationForm';

export default function FillSubscription() {
  return (
    <PersonalInformationForm />
  );
}
