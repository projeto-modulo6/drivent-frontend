import styled from 'styled-components';

export const ErrorMsg = styled.p`
  color: red;
`;
