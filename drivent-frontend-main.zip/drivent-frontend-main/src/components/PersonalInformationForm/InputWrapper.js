import styled from 'styled-components';

export const InputWrapper = styled.div`
> div {
  width: 100%;
}
`;
